export const DAYS = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thurday', 'Friday', 'Saturday']

export const MONTHS = [
    'January',
    'February',
    'March',
    'April',
    'May',
    'June',
    'July',
    'August',
    'September',
    'October',
    'November',
    'December'
    
]

export const SEASONS = {
    1 : "spring",
    2 : "summer",
    3 : "autumn",
    4 : "winter"
};
